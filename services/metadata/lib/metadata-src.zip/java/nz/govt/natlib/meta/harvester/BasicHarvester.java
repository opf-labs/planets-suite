package nz.govt.natlib.meta.harvester;


public class BasicHarvester extends NLNZHarvester {

	public String getOutputType() {
		return "simple.dtd";
	}
}
