package nz.govt.natlib.adapter.word.OLE;

public interface OLEConstants {
	public static final String OLE_HEADER = "D0 CF 11 E0 A1 B1 1A E1";
}
